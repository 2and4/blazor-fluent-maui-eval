import { Shell } from "../../shells/shell.js";
describe("Shell", () => {
    let _shell;
    let _documentMock;
    beforeEach(() => {
        _documentMock = createDocumentMock();
        _shell = new Shell(_documentMock);
    });
    it("construction -> successful", () => {
        expect(_shell).toBeTruthy();
    });
    function createDocumentMock() {
        return {
            body: {
                querySelector: (q) => { },
            },
            defaultView: {
                matchMedia: (q) => {
                    return {
                        addEventListener: () => { }
                    };
                }
            },
        };
    }
});
//# sourceMappingURL=shell.spec.js.map