import { ElementsHelper } from "../../helpers/elementsHelper.js";
describe("ElementsHelper", () => {
    let _elementsHelper;
    let _documentMock;
    beforeEach(() => {
        _documentMock = createDocumentMock();
        _elementsHelper = new ElementsHelper(_documentMock);
    });
    it("construction -> successful", () => {
        expect(_elementsHelper).toBeTruthy();
    });
    function createDocumentMock() {
        return {
            body: {
                querySelector: (q) => { },
            },
            defaultView: {
                matchMedia: (q) => {
                    return {
                        addEventListener: () => { }
                    };
                }
            },
        };
    }
});
//# sourceMappingURL=elementsHelper.spec.js.map