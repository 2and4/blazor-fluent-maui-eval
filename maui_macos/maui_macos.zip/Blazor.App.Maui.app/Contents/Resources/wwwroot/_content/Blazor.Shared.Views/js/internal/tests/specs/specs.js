import "../shells/shell.spec.js";
import "../animations/animations.spec.js";
import "../helpers/elementsHelper.spec.js";
import "../helpers/listViewHelper.spec.js";
import "../helpers/storageHelper.spec.js";
//# sourceMappingURL=specs.js.map