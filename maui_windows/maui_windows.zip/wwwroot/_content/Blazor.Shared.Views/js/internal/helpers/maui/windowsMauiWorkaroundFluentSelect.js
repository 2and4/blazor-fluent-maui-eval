export class WindowsMauiWorkaroundFluentSelect {
    constructor(document) {
        this._document = document;
        this._isSelectionOpen = false;
    }
    activate(elementId) {
        const element = this._document.getElementById(elementId);
        const fluentSelects = element === null || element === void 0 ? void 0 : element.querySelectorAll("fluent-select");
        if (!fluentSelects)
            return;
        fluentSelects.forEach((fluentSelect) => {
            const shadowRoot = fluentSelect.shadowRoot;
            const listbox = shadowRoot.querySelector(".listbox");
            this._isSelectionOpen = false;
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    var _a;
                    if (mutation.type === "attributes" && mutation.attributeName === "hidden") {
                        const listbox = mutation.target;
                        const isVisible = !listbox.hasAttribute("hidden");
                        this._isSelectionOpen = isVisible;
                        if (!isVisible)
                            return;
                        const listItemType = (_a = fluentSelect.querySelector("fluent-option")) === null || _a === void 0 ? void 0 : _a.constructor;
                        if (!listItemType)
                            return;
                        listItemType.prototype.scrollIntoView = function () { };
                    }
                });
            });
            observer.observe(listbox, {
                attributes: true
            });
            fluentSelect.addEventListener("focusout", (event) => {
                const fluentSelect = event.target;
                if (!this._isSelectionOpen)
                    return;
                fluentSelect.open = true;
                this._isSelectionOpen = false;
            });
        });
    }
}
//# sourceMappingURL=windowsMauiWorkaroundFluentSelect.js.map