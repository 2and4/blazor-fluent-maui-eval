import { ListViewHelper } from "../../helpers/listViewHelper.js";
describe("ListViewHelper", () => {
    let _listboxHelper;
    let _documentMock;
    beforeEach(() => {
        _documentMock = createDocumentMock();
        _listboxHelper = new ListViewHelper(_documentMock);
    });
    it("construction -> successful", () => {
        expect(_listboxHelper).toBeTruthy();
    });
    function createDocumentMock() {
        return {
            body: {
                querySelector: (q) => { },
            },
            defaultView: {
                matchMedia: (q) => {
                    return {
                        addEventListener: () => { }
                    };
                }
            },
        };
    }
});
//# sourceMappingURL=listViewHelper.spec.js.map