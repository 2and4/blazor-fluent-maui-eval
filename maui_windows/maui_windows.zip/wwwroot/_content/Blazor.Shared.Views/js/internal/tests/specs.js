export {};
//# sourceMappingURL=specs.js.map