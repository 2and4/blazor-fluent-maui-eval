export {};
//# sourceMappingURL=dotNetObjectReference.js.map