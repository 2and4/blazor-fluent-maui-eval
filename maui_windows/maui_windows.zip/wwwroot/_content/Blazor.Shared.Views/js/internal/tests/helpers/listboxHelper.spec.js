import { ListboxHelper } from "../../helpers/listboxHelper.js";
describe("ListboxHelper", () => {
    let _listboxHelper;
    let _documentMock;
    beforeEach(() => {
        _documentMock = createDocumentMock();
        _listboxHelper = new ListboxHelper(_documentMock);
    });
    it("construction -> successful", () => {
        expect(_listboxHelper).toBeTruthy();
    });
    function createDocumentMock() {
        return {
            body: {
                querySelector: (q) => { },
            },
            defaultView: {
                matchMedia: (q) => {
                    return {
                        addEventListener: () => { }
                    };
                }
            },
        };
    }
});
//# sourceMappingURL=listboxHelper.spec.js.map