import { StorageHelper } from "../../helpers/storageHelper.js";
describe("StorageHelper", () => {
    let _storageHelper;
    let _documentMock;
    beforeEach(() => {
        _documentMock = createDocumentMock();
        _storageHelper = new StorageHelper(_documentMock);
    });
    it("construction -> successful", () => {
        expect(_storageHelper).toBeTruthy();
    });
    function createDocumentMock() {
        return {
            body: {
                querySelector: (q) => { },
            },
            defaultView: {
                matchMedia: (q) => {
                    return {
                        addEventListener: () => { }
                    };
                }
            },
        };
    }
});
//# sourceMappingURL=storageHelper.spec.js.map