import { Animations } from "../../animations/animations.js";
describe("Animations", () => {
    let _animations;
    let _documentMock;
    beforeEach(() => {
        _documentMock = createDocumentMock();
        _animations = new Animations(_documentMock);
    });
    it("construction -> successful", () => {
        expect(_animations).toBeTruthy();
    });
    function createDocumentMock() {
        return {
            body: {
                querySelector: (q) => { },
            },
            defaultView: {
                matchMedia: (q) => {
                    return {
                        addEventListener: () => { }
                    };
                }
            },
        };
    }
});
//# sourceMappingURL=animations.spec.js.map