export class ListboxHelper {
    constructor(document) {
        this._document = document;
        this._itemsTagName = "fluent-option";
        this._selectedAttributeName = "selected";
        this._ariaSelectedAttributeName = "aria-selected";
    }
    updateSelection(elementId, selectedIndex) {
        const element = this._document.getElementById(elementId);
        if (!element)
            return;
        let itemsToClean = element.querySelectorAll(`[${this._selectedAttributeName}]`);
        itemsToClean === null || itemsToClean === void 0 ? void 0 : itemsToClean.forEach(ele => ele.removeAttribute(this._selectedAttributeName));
        itemsToClean = element.querySelectorAll(`[${this._ariaSelectedAttributeName}]`);
        itemsToClean === null || itemsToClean === void 0 ? void 0 : itemsToClean.forEach(ele => ele.removeAttribute(this._ariaSelectedAttributeName));
        const items = element.querySelectorAll(`${this._itemsTagName}`);
        const selectedItem = items[selectedIndex];
        if (!selectedItem)
            return;
        selectedItem.setAttribute(this._selectedAttributeName, "");
        selectedItem.setAttribute(this._ariaSelectedAttributeName, "true");
    }
}
//# sourceMappingURL=fluentListboxHelper.js.map